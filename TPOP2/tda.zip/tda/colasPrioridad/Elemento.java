package tda.colasPrioridad;

public class Elemento {
	int valor;
	int prioridad;
}
