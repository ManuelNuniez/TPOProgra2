package tda.diccionarios;

public class Elemento {
	int clave;
	int valor;
}
